/*
    SPDX-FileCopyrightText: 2010 Ivan Cukic <ivan.cukic(at)kde.org>
    SPDX-FileCopyrightText: 2013 Martin Klapetek <mklapetek(at)kde.org>
    SPDX-FileCopyrightText: 2025 Oliver Beard <olib141@outlook.com

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#pragma once

#include <QGuiApplication>
#include <QObject>
#include <QQmlEngine>
#include <QString>

#include <KPackage/PackageStructure>

class WallpaperWindow;

class WallpaperApp : public QGuiApplication
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.kde.plasma.wallpaper")

public:
    explicit WallpaperApp(int &argc, char **argv);

    // DBus interface
public Q_SLOTS:
    Q_SCRIPTABLE void blurScreen(const QString &screenName);

private:
    void createWindowForScreen(QScreen *screen);
    void setupWallpaperPlugin(WallpaperWindow *window);

    KPackage::Package m_wallpaperPackage;
    QList<WallpaperWindow *> m_windows;
    std::shared_ptr<QQmlEngine> m_engine;
};
