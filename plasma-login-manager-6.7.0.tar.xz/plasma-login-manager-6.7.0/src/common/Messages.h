/***************************************************************************
 * SPDX-FileCopyrightText: 2013 Abdurrahman AVCI <abdurrahmanavci@gmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ***************************************************************************/

#ifndef PLASMALOGIN_MESSAGES_H
#define PLASMALOGIN_MESSAGES_H

#include <QFlags>

namespace PLASMALOGIN
{
enum class GreeterMessages {
    Connect = 0,
    Login,
};

enum class DaemonMessages {
    LoginSucceeded,
    LoginFailed,
    InformationMessage,
};
}

#endif // PLASMALOGIN_MESSAGES_H
